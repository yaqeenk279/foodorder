<?php
    // Receiving values from the form
    $username = $_POST["username"];
    $password = $_POST["password"];
  

    // Displaying username, password, and email
    echo "<h2>User Information:</h2>";
    echo "<p>Username: $username</p>";
    echo "<p>Password: $password</p>";

    $conn=new mysqli("localhost","root","root123","foodorder");

$query="insert into food (username,password) value ('$username','$password')";
$run=mysqli_query($conn,$query);
echo " record inserted succesffuly";
    ?>