<?php
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $confirmpassword= trim($_POST["confirmpassword"]);
    $email = trim($_POST["email"]);
    $phonenumber = trim($_POST["phonenumber"]);

    echo "User name: $username";
    echo "<br>";
    echo "password: $password";
    echo "<br>";
    echo "confirmPassword: $confirmpassword";
    echo "<br>";
    echo "email: $email ";
    echo "<br>";
    echo "phone number: $phonenumber";

    $conn=new mysqli("localhost","root","root123","registration");

    $query="insert into register (username, password, confirmpassword, email, phonenumber) value ('$username','$password','$confirmpassword','$email','$phonenumber')";
    $run=mysqli_query($conn,$query);
    if($run){
    echo " record inserted succesffuly";
    } else {
    echo "Error: " . mysqli_error($conn);
    }
?>